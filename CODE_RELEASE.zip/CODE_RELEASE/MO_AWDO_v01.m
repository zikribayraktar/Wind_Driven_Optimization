function MO_AWDO_v01()
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
% Sample Matlab / Octave Code for the Multi-Objective Adaptive Wind Driven 
% Optimization algorithm. 
%
% Multi-objective numerical functions are tested. Fast non-dominated sorting
% algorithm from NSGA-II is utilized for determination of the Pareto-front.
% --> K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan, A Fast and elitist
% multiobjective genetic algorithm: NSGA-II, IEEE Transactions on 
% Evolutionary Computation, Vol. 6 (2002), no. 2, pp. 182-197.
% 
% Matlab code for "Fast non-dominated sorting" is provided by 
% Aravind Seshadri published publicly on Mathworks File Exchange: 
% https://www.mathworks.com/matlabcentral/fileexchange/10429-nsga-ii--a-multi-objective-optimization-algorithm
%
% Contact: Zikri Bayraktar, Ph.D. - thewdoalgorithm@gmail.com
%
% DISCLAIMER: This code is provided for educational purposes only. 
% Use at your own risk! There is no guarantee that the code is bug free.
% ------------------------------------------------------------------------
%  Redistribution and use in source and binary forms, with or without 
%  modification, are permitted provided that the following conditions are 
%  met:
%
%     * Redistributions of source code must retain the above copyright 
%       notice, this list of conditions and the following disclaimer.
%     * Redistributions in binary form must reproduce the above copyright 
%       notice, this list of conditions and the following disclaimer in 
%       the documentation and/or other materials provided with the distribution
%      
%  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
%  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
%  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
%  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
%  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
%  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
%  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
%  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
%  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
%  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
%  POSSIBILITY OF SUCH DAMAGE.
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
% Please refer to the following journal article in your publications:
%
% REFERENCE PAPERS:
%
%%%%% WDO %%%%%
% Z. Bayraktar, M. Komurcu, J. A. Bossard and D. H. Werner, The Wind 
% Driven Optimization Technique and its Application in Electromagnetics,
% IEEE Transactions on Antennas and Propagation, Volume 61, Issue 5, 
% pages 2745 - 2757, May 2013.
%
%%%%% Adaptive WDO (AWDO) %%%%%
% Z. Bayraktar and M. Komurcu, Adaptive Wind Driven Optimization,
% Proceedings of the 9th EAI International Conference on Bio-Inspired 
% Information and Communications Technologies (formerly BIONETICS), 
% New York City, NY, Dec. 3-5, 2015.
%
%%%%% NSGA-II %%%%%
% K. Deb, A. Pratap, S. Agarwal, and T. Meyarivan, A Fast and elitist
% multiobjective genetic algorithm: NSGA-II, IEEE Transactions on 
% Evolutionary Computation, Vol. 6 (2002), no. 2, pp. 182-197.
%
%%%%% CMAES %%%%%
% Hansen, N. and S. Kern (2004). Evaluating the CMA Evolution
% Strategy on Multimodal Test Functions.  Eighth International
% Conference on Parallel Problem Solving from Nature PPSN VIII,
% Proceedings, pp. 282-291, Berlin: Springer. 
% (http://www.bionik.tu-berlin.de/user/niko/ppsn2004hansenkern.pdf)
% 
% Hansen, N. and A. Ostermeier (2001). Completely Derandomized
% Self-Adaptation in Evolution Strategies. Evolutionary Computation,
% 9(2), pp. 159-195.
% (http://www.bionik.tu-berlin.de/user/niko/cmaartic.pdf).
%
% Hansen, N., S.D. Mueller and P. Koumoutsakos (2003). Reducing the
% Time Complexity of the Derandomized Evolution Strategy with
% Covariance Matrix Adaptation (CMA-ES). Evolutionary Computation,
% 11(1).  (http://mitpress.mit.edu/journals/pdf/evco_11_1_1_0.pdf).
%
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------

tic; clear; close all; clc;  
format long g;
%--------------------------------------------------------------

ArchiveParetoFronts = [];

% User defined parameters:
param.popsize = 100;	% population size.
param.npar = 10;         % Dimension of the problem.
param.maxit = 100;		% Maximum number of iterations.
maximumV = 0.5;             % maximum allowed speed.
%--------------------------------------------------------------

% AWDO will select the coefficient values; alpha, RT, g, c, and Vmax:
rec.arx = rand(5,param.popsize);   %consistent with the CMAES indexing
%---------------------------------------------------------------

% Initialize WDO population, position and velocity:
% Randomize population position in the range of [-1, 1]:
pos = 2*(rand(param.popsize,param.npar)-0.5);
% Randomize velocity in the range of [-Vmax, Vmax]:
vel = maximumV * 2 * (rand(param.popsize,param.npar)-0.5);  
%---------------------------------------------------------------

% Evaluate initial population via multi-objective function:
for K=1:param.popsize,
%     [f1,f2] = kursawe(pos(K,:));
%     [f1,f2] = kita(pos(K,:));
%     [f1,f2] = schaffer(pos(K,:));
%     [f1,f2] = ZDT1(pos(K,:));
    [f1,f2] = ZDT4(pos(K,:));
    pres(K,:) = [f1,f2];
end
%----------------------------------------------------------------
% 
% Call non-dominated sorting to identify the Pareto-front that each particle belongs:
posF=[pos, pres];
f = non_domination_sort_mod(posF, 2,param.npar);  % f = [pos, f1, f2, rank]

% extract the rank index, i.e. which Pareto-front the particle belongs:
rank_ind = f(:,param.npar+3);

% Select the Pareto-front == 1 particles as Global Best Position:
globalposPOP = f( (f(:,param.npar+3) ==1) , 1:param.npar);
% Archieve the rank 1 particles:
ArchiveParetoFronts = [ArchiveParetoFronts; f( (f(:,param.npar+3) ==1) , 1:(param.npar+2) )];

%-----------------------------------------------------------------
% Start iterations :
iter = 1;   % iteration counter
for ij = 2:param.maxit,
        ij
    	% Update the velocity:
    	for i=1:param.popsize
		% choose random dimensions:
		a = randperm(param.npar);        			
		% choose velocity based on random dimension:
    		velot(i,:) = vel(i,a);
            % randomly select a globalpos from the 1st Pareto-front members
            [aa, bb] = size(globalposPOP);
            globalpos = globalposPOP(round(((aa-1) * rand(1,1)) + 1),:);
        	vel(i,:) = (1-rec.arx(1,i))*vel(i,:)-(rec.arx(2,i)*pos(i,:))+ ...
				    abs(1-1/rank_ind(i))*((globalpos-pos(i,:)).*rec.arx(3,i))+ ...
				    (rec.arx(4,i)*velot(i,:)/rank_ind(i));   
        end
    
        % maxV is optimized by CMAES. Limit it maximumV defined by user
        maxV = rec.arx(5,:);
        maxV = min(maxV, repmat(maximumV, size(rec.arx(5,:),1),  size(rec.arx(5,:),2)) );
        maxV = max(maxV, repmat(-maximumV, size(rec.arx(5,:),1),  size(rec.arx(5,:),2)) );
        % Check velocity limits:
        vel = min(vel, repmat(maxV',1,param.npar));
        vel = max(vel, -repmat(maxV',1,param.npar));
        % Update air parcel positions:
    	pos = pos + vel;
        pos = min(pos, 1.0);
        pos = max(pos, -1.0); 
		% Evaluate population: (Pressure)
		for K=1:param.popsize,
%             [f1,f2] = kursawe(pos(K,:));
%             [f1,f2] = kita(pos(K,:));
%             [f1,f2] = schaffer(pos(K,:));
%             [f1,f2] = ZDT1(pos(K,:));
            [f1,f2] = ZDT4(pos(K,:));
            pres(K,:) = [f1,f2];
        end

        % Call non-dominated sorting to identify the Pareto-front that each particle belongs:
        posF=[pos, pres];
        f = non_domination_sort_mod(posF, 2,param.npar);  % f = [pos, f1, f2, rank]

        % extract the rank index, i.e. which Pareto-front the particle belongs:
        rank_ind = f(:,param.npar+3);

        % Select the Pareto-front == 1 particles and add them to the archieve along previous Pareto-fronts:
        ArchiveParetoFronts = [ArchiveParetoFronts; f( (f(:,param.npar+3) ==1) , 1:(param.npar+2) )];
        % Run the non-dominated sort among the Archieve members:
        f = non_domination_sort_mod(ArchiveParetoFronts, 2,param.npar);        
        % Replace the archieve with only the rank=1 members:
        ArchiveParetoFronts = f( (f(:,param.npar+3) ==1) , 1:(param.npar+2) );
        % Use rank=1 members as global position:
        globalposPOP = f( (f(:,param.npar+3) ==1) , 1:param.npar);  
       
        %--------------------------------
        % call CMAES 
        [rec] = purecmaes_wdo(ij,rec,param.popsize,pres(:, mod(ij,2)+1));
        %%% PRES has two values, pass one of the pres values at each iter
        %%% alternating between two.
    	%----------------------------------------------------

end
    
        %%% PLOT RESULTS:
        % Call non-dominant sorting:
        f = non_domination_sort_mod(ArchiveParetoFronts, 2,param.npar);

        % Plot the MO-results -- debugging purposes
        pres2plot = f( (f(:,param.npar+3) ==1) , param.npar+1 : param.npar+2);
        plot(pres2plot(:,1), pres2plot(:,2),'ko')
        xlabel('F1'); ylabel('F2')
        grid on
%         save('Results.mat','pres2plot')
        
        hold on
        % load the known-Pareto-front data for plotting:
        z = load('paretoZDT4.dat');
        [a,b]=sort(z(:,2));
        z = z(b,:);
        plot(z(:,1),z(:,2),'-k')
        
end
% end-of-WDO.

%----------------------------------------------------------------------
%----------------------------------------------------------------------
%----------------------------------------------------------------------

function [rec] = purecmaes_wdo(counteval,rec,npop,pressure)
%   coeff -- CMAES optimized coefficients returned to WDO.
%   counteval -- Iteration counter.
%   rec -- Record of prior values used in CMAES.
%   npop -- number of population members from WDO, each member gets their
%          own set of coefficients determined by the CMAES.
%   pressure -- pressure(cost function) computed by WDO for the set of
%               coefficients that CMEAS picked last iteration
%---------------------------------------------------------
%   This script is modified version of the publicly available purecmaes.m
%   Original "purecmaes.m" can be accessed from:
%   URL: http://www.lri.fr/~hansen/purecmaes.m
%
%   This function takes in pressure values from the WDO and computes new
%   set of coefficients for the WDO and returns them. In simpler terms, it
%   optimizes the WDO coefficients of "alpha, g, RT, c"
%
%   This function is not optimized, only proof-of-concept code to
%   illustrate that the WDO coefficients can be optimized by CMAES, 
%   which in turn creates and Adaptive WDO algorithm.
%---------------------------------------------------------

if counteval==2    %initialization only happens when the CMAES called for the first time.
    rec.N = 5;  % problem dimension is fixed to 4: alp, g, RT, c 
    rec.xmean = rand(rec.N,1);  % objective variables initial point
    rec.sigma = 0.5;        % coordinate wise standard deviation (step size)
  
    % Strategy parameter setting: Selection  
%     lambda = 4+floor(3*log(N));  % population size, offspring number
    rec.lambda = npop; %this is defined by the wdo population size.
    rec.mu = rec.lambda/2;               % number of parents/points for recombination
    rec.weights = log(rec.mu+1/2)-log(1:rec.mu)'; % muXone array for weighted recombination
    rec.mu = floor(rec.mu);        
    rec.weights = rec.weights/sum(rec.weights);     % normalize recombination weights array
    rec.mueff=sum(rec.weights)^2/sum(rec.weights.^2); % variance-effectiveness of sum w_i x_i

    % Strategy parameter setting: Adaptation
    rec.cc = (4 + rec.mueff/rec.N) / (rec.N+4 + 2*rec.mueff/rec.N); % time constant for cumulation for C
    rec.cs = (rec.mueff+2) / (rec.N+rec.mueff+5);  % t-const for cumulation for sigma control
    rec.c1 = 2 / ((rec.N+1.3)^2+rec.mueff);    % learning rate for rank-one update of C
    rec.cmu = min(1-rec.c1, 2 * (rec.mueff-2+1/rec.mueff) / ((rec.N+2)^2+rec.mueff));  % and for rank-mu update
    rec.damps = 1 + 2*max(0, sqrt((rec.mueff-1)/(rec.N+1))-1) + rec.cs; % damping for sigma 
                                                      % usually close to 1
    % Initialize dynamic (internal) strategy parameters and constants
    rec.pc = zeros(rec.N,1); 
    rec.ps = zeros(rec.N,1);   % pc, ps: evolution paths for C and sigma
    rec.B = eye(rec.N,rec.N);                       % B defines the coordinate system
    rec.D = ones(rec.N,1);                      % diagonal D defines the scaling
    rec.C = rec.B * diag(rec.D.^2) * rec.B';            % covariance matrix C
    rec.invsqrtC = rec.B * diag(rec.D.^-1) * rec.B';    % C^-1/2 
    rec.eigeneval = 0;                      % track update of B and D
    rec.chiN=rec.N^0.5*(1-1/(4*rec.N)+1/(21*rec.N^2));  % expectation of  ||N(0,I)|| == norm(randn(N,1))
end

    % get the fitness from WDO pressure:
    rec.arfitness = pressure';
    
    % Sort by fitness and compute weighted mean into xmean
    [rec.arfitness, rec.arindex] = sort(rec.arfitness);  % minimization
    rec.xold = rec.xmean;
    rec.xmean = rec.arx(:,rec.arindex(1:rec.mu)) * rec.weights;  % recombination, new mean value
    
    % Cumulation: Update evolution paths
    rec.ps = (1-rec.cs) * rec.ps ... 
          + sqrt(rec.cs*(2-rec.cs)*rec.mueff) * rec.invsqrtC * (rec.xmean-rec.xold) / rec.sigma; 
    rec.hsig = sum(rec.ps.^2)/(1-(1-rec.cs)^(2*counteval/rec.lambda))/rec.N < 2 + 4/(rec.N+1);
    rec.pc = (1-rec.cc) * rec.pc ...
          + rec.hsig * sqrt(rec.cc*(2-rec.cc)*rec.mueff) * (rec.xmean-rec.xold) / rec.sigma; 

    % Adapt covariance matrix C
    rec.artmp = (1/rec.sigma) * (rec.arx(:,rec.arindex(1:rec.mu)) - repmat(rec.xold,1,rec.mu));  % mu difference vectors
    rec.C = (1-rec.c1-rec.cmu) * rec.C ...                   % regard old matrix  
         + rec.c1 * (rec.pc * rec.pc' ...                % plus rank one update
                 + (1-rec.hsig) * rec.cc*(2-rec.cc) * rec.C) ... % minor correction if hsig==0
         + rec.cmu * rec.artmp * diag(rec.weights) * rec.artmp'; % plus rank mu update 

    % Adapt step size sigma
    rec.sigma = rec.sigma * exp((rec.cs/rec.damps)*(norm(rec.ps)/rec.chiN - 1)); 
    
    % Update B and D from C
    if counteval - rec.eigeneval > rec.lambda/(rec.c1+rec.cmu)/rec.N/10  % to achieve O(N^2)
      rec.eigeneval = counteval;
      rec.C = triu(rec.C) + triu(rec.C,1)'; % enforce symmetry
      [rec.B,rec.D] = eig(rec.C);           % eigen decomposition, B==normalized eigenvectors
      rec.D = sqrt(diag(rec.D));        % D contains standard deviations now
      rec.invsqrtC = rec.B * diag(rec.D.^-1) * rec.B';
    end
    
    % Generate and evaluate lambda offspring
    for k=1:rec.lambda,
        rec.arx(:,k) = rec.xmean + rec.sigma * rec.B * (rec.D .* randn(rec.N,1)); % m + sig * Normal(0,C) 
    end

end
% end-of-CMAES.


%----------------------------------------------------------------------
%----------------------------------------------------------------------
%----------------------------------------------------------------------
%%% TEST FUNCTIONS - MULTI-OBJECTIVE:
%----------------------------------------------------------------------
%----------------------------------------------------------------------
%----------------------------------------------------------------------
function [f1,f2] = kita(Xin)
% H. Kita, Y. Yabumoto, N. Mori, and Y. Nishikawa, Multi-objective 
% optimization by means of the thermodynamical genetic algorithm, 
% in Parallel Problem Solving From Nature�PPSN IV, H.-M. Voigt, W. Ebeling,
% I. Rechenberg, and H.-P. Schwefel, Eds. Berlin, Germany: SpringerVerlag, 
% Sept. 1996, Lecture Notes in Computer Science, pp. 504�512.
%
% Functions are to be maximized, hence -f1 and -f2 are returned to minimization:
%
% Xin is 2D dimensional vector.
% Due to constraints, limit the range of X,Y.  Constraints are:
%   0 >= x/6 + y - 13/2
%   0 >= x/2 + y - 15/2
%   0 >= 5x + y - 30
%   0 <= x,y
% Limit:   x = [0, 6] and y = [0, 6.5]
x = 7.0 * ( Xin(1)/2 + 0.5 ); 
y = 7.0 * ( Xin(2)/2 + 0.5 );

f1 = -(x*x) + y;
f2 = (x/2) + y + 1;

f1 = 1/f1;
f2 = 1/f2;
end
%-----------------------------
function [smf1, smf2] = kursawe(Xin)
% F. Kursawe, A variant of evolution strategies for vector optimization,
% in Lecture Notes in Computer Science, H. P. Schwefel and R. M�nner,
% Eds. Berlin, Germany: Springer-Verlag, Oct 1991, vol. 496, Proc.
% Parallel Problem Solving From Nature, 1st Workshop, PPSN I, pp. 193�197.
%
% Functions are to be minimized. Xin can be arbitrary length.
%
% Limit:  -5 < x < 5
%
x = 10 .* ( Xin./2 + 0.5 ) - 5; 
[a,b] = size(Xin);
smf1 = 0;
for i=1:b-1
    smf1 = smf1 - 10*exp(-0.2*sqrt(x(i)^2 + x(i+1)^2));
end

smf2 = 0;
for i=1:b
    smf2 = smf2 + (abs(x(i))^0.8 + 5*sin(x(i)^3)); 
end
end

%-----------------------------
function [f1, f2] = schaffer(Xin)
% Limit:  -10^3 < x < 10^3

x = 2*10^3 .* ( Xin./2 + 0.5 ) - 10^3; 

f1 = x.^2;
f2 = (x-2).^2;

% look up Deb's paper for this test function
end
%-----------------------------
function [f1, f2] = ZDT4(Xin)
% x1 [0,1]
% x(2:end)  [-5,5]
n = length(Xin);

x1 = (Xin(1)/2+0.5); 
x = 10 .* ( Xin(2:end)./2 + 0.5 ) - 5; 

f1 = x1;

g = 1 + 10*(n-1) + sum( (x.^2)-10*cos(4*pi.*x) );
% g =1;
f2 = g * (1 - sqrt(x1/g));

% look up Deb's paper for this test function
end
%-----------------------------
function [f1, f2] = ZDT1(Xin)
% x [0,1]
n = length(Xin);

x = ( Xin./2 + 0.5 ); 

f1 = x(1);

gg = 1 + 9.* sum( x(2:end) ) ./ (n-1);
% g =1;
f2 = gg * (1 - sqrt(x(1)./gg));

% look up Deb's paper for this test function
end

%----------------------------------------------------------------------
%----------------------------------------------------------------------
%----------------------------------------------------------------------
% end-of-file